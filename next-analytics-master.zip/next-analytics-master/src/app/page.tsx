export default function Home() {
  // IMPORTANT: This analytics dashboard is compatible with any app, your main app lives here!

  return <main>This is an example</main>
}
